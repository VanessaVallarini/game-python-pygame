from time import time
import sys, pygame
import random
from sprites.cores import Cores
from sprites.sons import Sons
from sprites.jogador import Jogador
from sprites.utils import Utils
from sprites.imagens import Imagens
from sprites.inimigos import Inimigos

pygame.init()

#####IMAGENS
imagens = Imagens()

#####SONS
sons = Sons()

#####JOGADOR
jogador = Jogador()

#####UTILS
utils = Utils()

#####INTRO:
intro = True

#####SETAR TELA:
tela = (800, 600)
screen = pygame.display.set_mode(tela)
screen.fill(Cores.WHITE)

#####CLOCK:
clock = pygame.time.Clock()

#####ICON:
pygame.display.set_icon(imagens.icon)
pygame.display.set_caption("ZATHURA")

#####MENU:
menu = True

#####TRANSICAO:
transi_flag = True

#####IMAGEM DE FUNDO:
espaco = imagens.espaco

#####IMAGEM VIDAS:
imagem_vida = imagens.imagem_vida

#####PONTUACÃO
ultimo_blit = 0
mostrar_pontuacao = False

#####LEVEL:
mostrar_level = True
nivel_fase = 1
apresentar_clear=False
level = "lvl_01"

#####RECOMECO:
recomeco=True

#INIMIGOS:
inimigos = Inimigos()

#####BLITAR_ESPAÇO:
def blitar_espaco():
    screen.blit(espaco,[0, 0])

#####BLITAR_VIDAS:
def blitar_vidas(tempo):
  menu = False
  if jogador.vidas >= 0:
    for i in range(len(jogador.lista_x_vidas)):
      screen.blit(imagem_vida, [jogador.lista_x_vidas[i],550])
  else:
    jogador.pontos = utils.mostrar_pontuacao(tempo,jogador.pontos)
    utils.perder_jogo(screen,jogador.pontos)
    utils.mostrar_resultado(tempo,screen,jogador.vidas,jogador.pontos)
    menu = True
    return recomecar_jogo(tempo,1)
  return menu

#####COLISAO_TIRO_PLAYER_X_INIMIGO:
def acertar_tiro_player():
    global tempo
    if len(jogador.bullets)>0:
        cont=0
        while cont<len(jogador.bullets):
            for a in range(len(inimigos.inimigos_na_tela)):
                if jogador.bullets[cont]<=inimigos.inimigos_na_tela[a][1]+ inimigos.inimigos_na_tela[a][4]<=jogador.bullets[cont]+inimigos.inimigos_na_tela[a][4] and inimigos.inimigos_na_tela[a][2]<=jogador.bullets[cont+1]+5<=inimigos.inimigos_na_tela[a][2]+inimigos.inimigos_na_tela[a][5]:
                    sons.acertou_inimigo()
                    del jogador.bullets[cont+1]
                    del jogador.bullets[cont]
                    inimigos.inimigos_na_tela[a][6] -= 2
                    if inimigos.inimigos_na_tela[a][6] == 0:
                        tempo_ini=tempo
                        inimigos.explosao(inimigos.inimigos_na_tela[a][1],inimigos.inimigos_na_tela[a][2],inimigos.inimigos_na_tela[a][0],tempo_ini)
                        jogador.pontos += 100
                        if inimigos.inimigos_na_tela[a][0]==2:
                          jogador.pontos += 400
                        if inimigos.inimigos_na_tela[a][0]==3:
                          jogador.pontos += 900
                        del inimigos.inimigos_na_tela[a]
                    cont -= 2
                    break
            cont += 2

#####COLISAO_TIRO_INIMIGO_X_TIRO_PLAYER:
def verificar_tiro_inimigo():
  if len(inimigos.red_bullets)>0:
        cont=0
        while cont<len(inimigos.red_bullets):
            if inimigos.red_bullets[cont] <= jogador.x_nave+150 <= inimigos.red_bullets[cont]+150 and jogador.y_nave <= inimigos.red_bullets[cont+1]+5 <= jogador.y_nave + 43:
                sons.perdeu_vida()
                del inimigos.red_bullets[cont+1]
                del inimigos.red_bullets[cont]
                jogador.vidas -= 1
                if jogador.vidas >= 0:
                  del jogador.lista_x_vidas[jogador.vidas]
                cont -= 2
            cont += 2
  if len(inimigos.bullets_inimigos)>0:
        cont=0
        while cont<len(inimigos.bullets_inimigos):
            if inimigos.bullets_inimigos[cont]<=jogador.x_nave+150<=inimigos.bullets_inimigos[cont]+150 and jogador.y_nave <= inimigos.bullets_inimigos[cont+1] + 5 <= jogador.y_nave+43:
                del inimigos.bullets_inimigos[cont+1]
                del inimigos.bullets_inimigos[cont]
                jogador.vidas -= 1
                if jogador.vidas >= 0:
                  del jogador.lista_x_vidas[jogador.vidas]           
                cont -= 2
            cont += 2
            
def recomecar_jogo(tempo,metodo):
  global menu
  menu = True
  global transi_flag
  transi_flag = True
  global seconds
  seconds=pygame.time.get_ticks()-tempo
  global nivel_fase
  nivel_fase=1
  global mostrar_level
  mostrar_level=True
  global apresentar_clear
  apresentar_clear=False
  global level
  level = "lvl_01"
  global mostrar_pontuacao
  mostrar_pontuacao = False
  jogador.last_time = 0
  jogador.bullets = []
  jogador.pontos = 0
  jogador.x_nave = 0
  jogador.y_nave = 200
  jogador.vidas=3
  jogador.lista_x_vidas=[0,80,160] 
  inimigos.red_bullets = []
  inimigos.bullets_chefao = []
  inimigos.inimigos_na_tela = []
  inimigos.indice_lista_inimigos = 0
  inimigos.lista_explosao=[]
  global recomeco
  recomeco=False
  pygame.display.update()
  if metodo==2:
    return nivel_fase, inimigos.indice_lista_inimigos, mostrar_level
  else:
    return jogador.lista_x_vidas, menu, jogador.vidas

while True:
    #MENU:
    if sons.mus:
        sons.musica()
        pygame.time.delay(2000)
        sons.mus=False
    #INTRO:
    if intro:
      intro = utils.introducao(screen,intro,clock)
    #MENU:
    if menu:
      menu = utils.iniciar_menu(menu,screen)
    #TRANSICAO:
    if transi_flag:
      transi_flag = utils.transicao(screen,transi_flag,clock)
      start_ticks=pygame.time.get_ticks() 
    seconds = (pygame.time.get_ticks() - start_ticks)/1000
    tempo = seconds
    #BLITAR_ESPACO:
    blitar_espaco()
    #BLITAR_VIDAS:
    menu = blitar_vidas(tempo)
    #BLITAR_EXPLOSAO_INIMIGOS:
    inimigos.blitar_explosao(tempo,screen)
    #ACRESENTAR_INIMIGOS/APRESENTAR_NIVEL/PONTUACAO/RANK/RESULTADO/RECOMECAR:
    if recomeco:
      mostrar_level,level,apresentar_clear,nivel_fase = inimigos.acrescentar_inimigos(nivel_fase,mostrar_level,apresentar_clear,level)
      if apresentar_clear:
          jogador.bullets,inimigos.red_bullets,inimigos.bullets_inimigos,apresentar_clear,tempo = utils.apresentar_clear(screen,jogador.bullets,inimigos.red_bullets,inimigos.bullets_inimigos,"stage",apresentar_clear,tempo)
      if mostrar_level:
          mostrar_level = utils.apresentar_level(screen,level)
      if mostrar_pontuacao:
          jogador.mostrar_pontuacao(tempo,jogador.vidas)
          utils.rankear(screen,jogador.pontos)
          utils.mostrar_resultado(tempo,screen,jogador.vidas,jogador.pontos)
          recomecar_jogo(tempo,2)
    #MOVIMENTACAO_INIMIGOS:
    inimigos.spawn_inimigos(0,screen) 
    #BLITAR_PERSONAGEM:
    jogador.blitar_personagem(screen)
    #MOVIMENTACAO_PERSONAGEM:
    jogador.movimentacao_personagem(screen)
    #PAUSAR:
    keypause = pygame.key.get_pressed()
    if keypause[pygame.K_p]:
        tempo = utils.paused(screen,tempo)
    #BLITAR_TIRO_PERSONAGEM:
    jogador.blitar_tiro_personagem(screen)
    #BLITAR_TIRO_INIMIGO:
    inimigos.blitar_tiro_inimigo(screen)
    #BLITAR_TIRO_CHEFAO:
    inimigos.blitar_tiro_chefao(screen)
    
    verificar_tiro_inimigo()
    acertar_tiro_player()
    
    #SCORE:
    utils.pontuar(screen, jogador.pontos)
    #TEMPO:
    ultimo_blit = utils.mostrar_tempo(tempo,ultimo_blit,screen)
    
    if inimigos.indice_lista_inimigos == 9 and len(inimigos.inimigos_na_tela) > 0:
      barra_verde = inimigos.barra_de_vida_boss(screen)
    jogador.x_nave,jogador.y_nave = utils.colisao(jogador.x_nave, 0, jogador.y_nave, 0, 88, 800, 43, 600, True)
    pos_nave=pygame.Rect(jogador.x_nave,jogador.y_nave,88,43)
    for a in range(len(inimigos.inimigos_na_tela)):
      inimigo=pygame.Rect(inimigos.inimigos_na_tela[a][1],inimigos.inimigos_na_tela[a][2],inimigos.inimigos_na_tela[a][4],inimigos.inimigos_na_tela[a][5])
      if pos_nave.colliderect(inimigo):
        jogador.x_nave=inimigos.inimigos_na_tela[a][1]-88
    if recomeco == False:
      recomeco=True
    clock.tick(60)
    pygame.display.update()
