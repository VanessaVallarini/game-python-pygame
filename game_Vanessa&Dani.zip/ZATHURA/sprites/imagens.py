import sys, pygame

class Imagens(object):
    icon = pygame.image.load('imagens/icon.png')
    logo = pygame.image.load('imagens/logo.png')
    game_logo = pygame.image.load('imagens/game_logo.png')
    instrucao_menu = pygame.image.load('imagens/instrucao_menu.png')
    espaco = pygame.image.load('imagens/espaco.png')
    nave = pygame.image.load('imagens/nave.png')
    imagem_vida = pygame.transform.scale(nave, (66, 33))
    game_over = pygame.image.load('imagens/game_over.png')
    pontuacao = pygame.image.load('imagens/pontuacao.png')
    lvl_01 = pygame.image.load('imagens/level_1.png')
    lvl_02 = pygame.image.load('imagens/level_2.png')
    lvl_final = pygame.image.load('imagens/level_final.png')
    stage = pygame.image.load('imagens/stage.png')
    inimigo_01 = pygame.image.load("imagens/inimigo_01.png")
    inimigo_02 = pygame.image.load("imagens/inimigo_02.png")
    inimigo_03 = pygame.image.load("imagens/inimigo_03.png")
    inimigo_04 = pygame.image.load("imagens/inimigo_04.png")
    explosao_inimigos = pygame.image.load("imagens/explosao.png")
    explosao_chefao = pygame.image.load("imagens/explosao_chefao.jpg")
    

  
