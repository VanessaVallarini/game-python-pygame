import sys, pygame

pygame.init()
pygame.mixer.init()

class Sons(object):
    mus = True

    pygame.mixer.music.load("musicas/ACDC.mp3")   

    def musica(self):
        pygame.mixer.music.play(-1)
        pygame.display.update()

    def tiro_player(self):
        tiro_player = pygame.mixer.Sound("musicas/tiro_player.wav")
        tiro_player.set_volume(.5)
        pygame.mixer.Sound.play(tiro_player)
        tiro_player.play()

    def acertou_inimigo(self):
        acertou_inimigo = pygame.mixer.Sound("musicas/acertou_inimigo.WAV")
        acertou_inimigo.set_volume(.5)
        pygame.mixer.Sound.play(acertou_inimigo)
        acertou_inimigo.play()

    def game_over(self):
        game_over = pygame.mixer.Sound("musicas/game_over.ogg")
        game_over.set_volume(.7)
        pygame.mixer.Sound.play(game_over)
        game_over.play()

    def perdeu_vida(self):
        perdeu_vida = pygame.mixer.Sound("musicas/perdeu_vida.ogg")
        perdeu_vida.set_volume(.5)
        pygame.mixer.Sound.play(perdeu_vida)
        perdeu_vida.play()   

    def stop(self):
        pygame.mixer.music.stop()

    def intro(self):
        intro = pygame.mixer.Sound("musicas/intro.wav")
        intro.set_volume(.7)
        pygame.mixer.Sound.play(intro)
        intro.play()
        

    

