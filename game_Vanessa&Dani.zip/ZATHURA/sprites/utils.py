import sys, pygame
from time import time
from sprites.sons import Sons
from sprites.cores import Cores
from sprites.jogador import Jogador
from sprites.imagens import Imagens


class Utils(object):
    imagens = Imagens()
    logo = imagens.logo
    game_logo = imagens.game_logo
    font = "8-Bit-Madness.ttf"
    espaco = imagens.espaco
    instrucao_menu = imagens.instrucao_menu
    inimigo_04 = imagens.inimigo_04
    game_over = imagens.game_over
    lista_rank = [000, 000, 000]
    lista_nome =["AAA", "AAA", "AAA"]
    alfabeto = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M',
                'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
    pontuacao = imagens.pontuacao
    lvl_01 = imagens.lvl_01
    lvl_02 = imagens.lvl_02
    lvl_final = imagens.lvl_final
    stage = imagens.stage   
    jogador = Jogador()
    sons = Sons()
    pause = False

    def text_objects(self, text, font):
        textSurface = font.render(text, True, Cores.BLACK)
        return textSurface, textSurface.get_rect()

    def introducao(self, screen, intro, clock):
        i=1
        while i<256:
            screen.fill(Cores.BLACK)
            screen.blit(self.logo,[300,200])
            intro = False
            i+=1
            clock.tick(60)
            pygame.display.flip()
        return intro

    def iniciar_menu(self,menu,screen):
        while menu:
            mouse = pygame.mouse.get_pos()
            pres = pygame.mouse.get_pressed()[0]
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
            screen.fill(Cores.BLACK)
            screen.blit(self.game_logo, [240,140])
            if 200+100 > mouse[0]>200 and 400+50> mouse[1]> 400:
                pygame.draw.rect(screen, Cores.LIGHT_BLUE, (200,400,100,50))
                if pres:
                    menu = False
                    break
            else:
                pygame.draw.rect(screen, Cores.GREEN, (200,400,100,50))
            if 500+100 > mouse[0]>500 and 400+50> mouse[1]> 400:
                pygame.draw.rect(screen, Cores.LIGHT_BLUE, (500,400,100,50))
                if pres:
                    menu = False
                    self.instruir(screen)
            else:
                pygame.draw.rect(screen, Cores.GREEN, (500,400,100,50))
            #botao 1
            fonte=pygame.font.Font(self.font,30)
            texto, textoRect = self.text_objects("JOGAR",fonte)
            textoRect.center = ( (200+(100/2)), (400+(50/2)) )
            screen.blit(texto, textoRect)
            #botao 2
            fonte=pygame.font.Font(self.font,30)
            texto, textoRect = self.text_objects("MENU",fonte)
            textoRect.center = ( (500+(100/2)), (400+(50/2)) )
            screen.blit(texto, textoRect)
            pygame.display.update()
        return False

    def instruir(self,screen):
        inst = True
        while inst:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                mouse = pygame.mouse.get_pos()
                pres = pygame.mouse.get_pressed()[0]
                screen.blit(self.espaco,[0, 0])
                screen.blit(self.instrucao_menu,[250,50])
                #botao jogar
                pygame.draw.rect(screen, Cores.GREEN, (350,500,100,50))
                if 350+100 > mouse[0]>350 and 500+50> mouse[1]> 500:
                    pygame.draw.rect(screen, Cores.LIGHT_BLUE, (350,500,100,50))
                    if pres:
                        inst = False
                fonte=pygame.font.Font(self.font,30)
                texto, textoRect = self.text_objects("JOGAR",fonte)
                textoRect.center = ( (350+(100/2)), (500+(50/2)) )
                screen.blit(texto, textoRect)
                pygame.display.update()

    def transicao(self, screen,transi_flag,clock):
        x = 0
        y = 200
        x_chefao = 1000
        y_chefao = 100
        flag = False
        self.sons.stop() 
        while True:
            screen.blit(self.espaco,[0, 0])
            screen.blit(self.jogador.nave, [x,y])
            screen.blit(self.inimigo_04, [x_chefao,y_chefao])
            if x < 100:
                x += 3
            if x >=100 and x<=200:
                self.sons.intro()
            if x >= 100  and x_chefao >= 300:
                x_chefao -= 3
                if x_chefao <= 300:
                    flag = True     
            if flag:
                x_chefao += 7
                if x_chefao > 400:
                    x += 5
                if x > 800:
                    transi_flag = False
                    break
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
            pygame.display.update()
            clock.tick(80)
        pygame.mixer.music.play(-1)
        return transi_flag

    def mostrar_pontuacao(self, tempo, pontos):
        pontos -= int(tempo)
        return pontos

    def perder_jogo(self,screen,pontos):
        self.sons.stop()
        self.sons.game_over()
        cont = 0
        for x in range(0, 200):
            screen.fill(Cores.BLACK)
            screen.blit(self.game_over, [0, 0])
            pygame.display.flip()
            cont += 1
        self.rankear(screen,pontos)

    def rankear(self,screen,pontos):
        if pontos >= self.lista_rank[2]:
            self.lista_rank[2] = pontos
            self.lista_rank.sort()
            self.lista_rank.reverse()
            indice = self.lista_rank.index(pontos)
            nome = self.colocar_nome(screen)
            self.lista_nome[2] = nome
            for i in range(indice, len(self.lista_nome)):
                aux = self.lista_nome[i]
                self.lista_nome[i] = self.lista_nome[indice]
                self.lista_nome[indice] = aux

    def colocar_nome(self,screen):
        cont = 0
        cont_nome = 0
        letra_nome = [self.alfabeto[0], self.alfabeto[0], self.alfabeto[0]]
        textao = "INSIRA SUAS INICIAIS: "
        instrucao = "Para trocar de letras, utilize as setas."
        instrucao2 = "Para confirmar, pressione a tecla SPACE!"
        fonte1 = pygame.font.Font(self.font, 35)
        fonte2 = pygame.font.Font(self.font, 50)
        fonte3 = pygame.font.Font(self.font, 70)
        mensagem4 = fonte2.render(textao, 1, Cores.WHITE)
        mensagem5 = fonte1.render(instrucao, 1, Cores.WHITE)
        mensagem6 = fonte1.render(instrucao2, 1, Cores.WHITE)
        while True:
            screen.fill(Cores.BLACK)
            mensagem1 = fonte3.render(letra_nome[0], 1, Cores.WHITE)
            mensagem2 = fonte3.render(letra_nome[1], 1, Cores.WHITE)
            mensagem3 = fonte3.render(letra_nome[2], 1, Cores.WHITE)
            screen.blit(mensagem1, (320, 250))
            screen.blit(mensagem2, (370, 250))
            screen.blit(mensagem3, (420, 250))
            screen.blit(mensagem4, (170, 100))
            screen.blit(mensagem5, (100, 400))
            screen.blit(mensagem6, (100, 450))
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                keys = pygame.key.get_pressed()
                if keys[pygame.K_RIGHT]:
                    if cont < 25:
                        cont += 1
                    else:
                        cont = 0
                if keys[pygame.K_LEFT]:
                    if cont < 0:
                        cont = 25
                    else:
                        cont -= 1
                if keys[pygame.K_SPACE]:
                    if cont_nome == 2:
                        nome_final = ''
                        for i in range(3):
                            nome_final += letra_nome[i]
                        return nome_final
                    cont_nome += 1
                    cont = 0
            letra_nome[cont_nome] = self.alfabeto[cont]
            pygame.display.update()

    def mostrar_resultado(self,tempo,screen,vidas,pontos):
        if vidas < 0:
            vidas = 0
        menu = True
        resultado = "Seus pontos: " + str(pontos)
        temporal = "Seu tempo total: " + str(int(tempo))
        nome1 = '1st ' + str(self.lista_nome[0]) + " - " + str(self.lista_rank[0])
        nome2 = '2nd ' + str(self.lista_nome[1]) + " - " + str(self.lista_rank[1])
        nome3 = '3rd ' + str(self.lista_nome[2]) + " - " + str(self.lista_rank[2])
        fonte1 = pygame.font.Font(self.font, 35)
        fonte2 = pygame.font.Font(self.font,28)
        texto, textoRect = self.text_objects("JOGAR", fonte2)
        textoRect.center = ( (300 + (200/2)), (500+(50/2)))
        mensagem3 = fonte1.render(nome1, 1, Cores.WHITE)
        mensagem4 = fonte1.render(nome2, 1, Cores.WHITE)
        mensagem5 = fonte1.render(nome3, 1, Cores.WHITE)
        while menu == True:
            mouse = pygame.mouse.get_pos()
            pres = pygame.mouse.get_pressed()[0]
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
        
            screen.blit(self.pontuacao, [0,0])
            mensagem1 = fonte1.render(resultado, 1, Cores.WHITE)
            mensagem2 = fonte1.render(temporal, 1, Cores.WHITE)
            screen.blit(mensagem1, (295, 400))
            screen.blit(mensagem2, (295, 430))
            screen.blit(mensagem3, (200, 180))
            screen.blit(mensagem4, (200, 210))
            screen.blit(mensagem5, (200, 240))
            
            if 300 + 200 > mouse[0] > 300 and 500 + 50 > mouse[1] > 500:
                pygame.draw.rect(screen, Cores.LIGHT_BLUE, (300, 500, 200, 50))
                if pres:
                    menu = False
                    return menu
            else:
                pygame.draw.rect(screen, Cores.GREEN, (300,500,200,50))
            screen.blit(texto, textoRect)
            pygame.display.update()

    def pontuar(self, screen, pontos):
        pt = pontos
        text = 'score: '+str(pt)
        fonte = pygame.font.Font(self.font, 35)
        mensagem = fonte.render(text, 1, (255, 255, 255))
        screen.blit(mensagem, (10, 10))

    def mostrar_tempo(self,tempo,ultimo_blit,screen):
        tempo=int(tempo)
        texto = str(ultimo_blit)
        fonte = pygame.font.Font(self.font, 35)
        mensagem = fonte.render(texto, 1, (255, 255, 255))
        if ultimo_blit != tempo:
            ultimo_blit=tempo
        screen.blit(mensagem, (380, 10))
        return ultimo_blit

    def apresentar_level(self, screen, lvl):
        cont = 0
        while True:
            if lvl == "lvl_01":
                screen.blit(self.lvl_01, [0,0])
            if lvl == "lvl_02":
                screen.blit(self.lvl_02, [0,0])
            if lvl == "lvl_final":
                screen.blit(self.lvl_final, [0,0])
            pygame.display.update()
            cont+=1
            if cont == 250:
                return False
                break

    def apresentar_clear(self, screen,bullets,red_bullets,bullets_boss,stage,apresentar_clear,tempo):
        pygame.time.delay(500)
        screen.blit(self.stage, [0, 0])
        bullets = []
        red_bullets = []
        bullets_boss = []
        pygame.display.update()
        pygame.time.delay(2000)
        apresentar_clear = False
        return bullets,red_bullets,bullets_boss,apresentar_clear,tempo

    def colisao(self,x_nave,x_max,y_nave,y_max,w_nave,w_max,h_nave,h_max,condicao):
        if condicao:
            if  x_nave <= x_max :
                x_nave = x_max
            if x_nave + w_nave >= x_max + w_max:
                x_nave = (x_max + w_max) - w_nave
            if y_nave <= y_max:
                y_nave = y_max
            if y_nave + h_nave >= y_max + h_max:
                y_nave = (y_max + h_max) - h_nave
        return x_nave, y_nave

    def paused(self,screen,tempo):
        aux_tempo = tempo
        self.pause = True
        while self.pause:
            texto = "JOGO PAUSADO"
            instrucao = "USE A TECLA R PARA RETORNAR!"
            fonte = pygame.font.Font(self.font, 30)
            fonte2 = pygame.font.Font(self.font, 90)
            mensagem = fonte2.render(texto, 1, Cores.WHITE)
            mensagem2 = fonte.render(instrucao, 1, Cores.WHITE)
            screen.blit(mensagem, (150, 200))
            screen.blit(mensagem2, (230, 280))
            pygame.display.update()
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_r:
                        self.pause = False
                        return aux_tempo





