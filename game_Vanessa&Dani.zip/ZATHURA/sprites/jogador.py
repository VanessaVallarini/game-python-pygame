import sys, pygame
from time import time
from sprites.sons import Sons
from sprites.cores import Cores
from sprites.imagens import Imagens

class Jogador(object):
    imagens = Imagens()
    nave = imagens.nave
    x_nave = 0
    y_nave = 200    
    pontos = 0
    bullets = []
    vidas = 3
    lista_x_vidas=[0, 80, 160]
    last_time = 0
    sons = Sons()
    font = "8-Bit-Madness.ttf"

    def blitar_personagem(self, screen):
        return screen.blit(self.nave, [self.x_nave, self.y_nave])

    def movimentacao_personagem(self,screen):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
        keys = pygame.key.get_pressed()
        if keys[pygame.K_d] and keys[pygame.K_a]:
            self.x_nave += 4
        if keys[pygame.K_d]:
            self.x_nave += 4
        if keys[pygame.K_a]:
            self.x_nave -= 4
        if keys[pygame.K_w]:
            self.y_nave -= 4
        if keys[pygame.K_s]:
            self.y_nave += 4
        if keys[pygame.K_SPACE]:
            self.atirar()

    def atirar(self):
        if time()-self.last_time>0.2:
            self.sons.tiro_player()
            self.bullets.append(self.x_nave+100)
            self.bullets.append(self.y_nave+40)
            self.last_time=time()

    def blitar_tiro_personagem(self, screen):
        for b in range(0,len(self.bullets),2):
            self.bullets[b] += 10
        for b in range(0,len(self.bullets),2):
            if len(self.bullets) > 0:
                if self.bullets[0] > 800:
                    del self.bullets[b + 1]
                    del self.bullets[b]
        for b in range(0,len(self.bullets),2):
            pygame.draw.rect(screen, Cores.GREEN, (self.bullets[b], self.bullets[b+1], 5, 5))

