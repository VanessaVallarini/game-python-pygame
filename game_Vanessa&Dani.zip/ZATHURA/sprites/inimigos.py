import sys, pygame
import random
from time import time
from sprites.sons import Sons
from sprites.cores import Cores
from sprites.imagens import Imagens
from sprites.utils import Utils

class Inimigos(object):
    imagens = Imagens()
    inimigo_01 = imagens.inimigo_01
    inimigo_02 = imagens.inimigo_02
    inimigo_03 = imagens.inimigo_03
    inimigo_04 = imagens.inimigo_04    
    red_bullets = []
    bullets_inimigos = []
    inimigos_na_tela = []
    lista_inimigos=[[inimigo_01,69,68],[inimigo_02,57,47],[inimigo_03,300,273],[inimigo_04,350,331]]
    lista_inimigos_fases = [4,4,5,5,6,4,4,1,1,0]
    indice_lista_inimigos = 0   
    explosao_inimigos = imagens.explosao_inimigos 
    explosao_chefao = imagens.explosao_chefao
    lista_explosao=[]  
    lista_pos_chefao = [4, 2, 0, -2, -4]
    lista_pos_miniChefao = [2, 0, -2]
    utils = Utils()
    
    def acrescentar_inimigos(self,nivel_fase,mostrar_level,apresentar_clear,level):
        if nivel_fase == 1:
            if mostrar_level:
                mostrar_level = True
                level = ("lvl_01")
            if len(self.inimigos_na_tela)==0:
                self.lista_y_inimigo=[]
                for i in range(1,self.lista_inimigos_fases[self.indice_lista_inimigos]+1):
                    self.lista_y_inimigo.append(500//4)
                for i in range(self.lista_inimigos_fases[self.indice_lista_inimigos]):
                    self.gerar_inimigos(i,0)
                if self.indice_lista_inimigos == 5:
                    apresentar_clear = True
                    nivel_fase = 2
                    level = ("lvl_02")
                    mostrar_level = True
                self.indice_lista_inimigos += 1

        if nivel_fase == 2:
            if mostrar_level:
                mostrar_level = True
                level = ("lvl_02")
            if len(self.inimigos_na_tela)==0:
                self.lista_y_inimigo=[]
                for i in range(1,self.lista_inimigos_fases[self.indice_lista_inimigos]+1):
                    self.lista_y_inimigo.append(500//4)
                for i in range(self.lista_inimigos_fases[self.indice_lista_inimigos]):
                    if self.indice_lista_inimigos == 7:
                        self.gerar_inimigos(i,1)
                    if self.indice_lista_inimigos < 7:
                        self.gerar_inimigos(i,0)
                if self.indice_lista_inimigos == 8:
                    apresentar_clear = True
                    nivel_fase=3
                    level = ("lvl_final")
                    mostrar_level=True
                    self.indice_lista_inimigos-=1
                self.indice_lista_inimigos+=1

        if nivel_fase == 3:
            if mostrar_level:
                mostrar_level = True
                level = ("lvl_final")
            if len(self.inimigos_na_tela)==0:
                self.lista_y_inimigo=[]
                for i in range(1,self.lista_inimigos_fases[self.indice_lista_inimigos]+1):
                    self.lista_y_inimigo.append(500//4)
                for i in range(self.lista_inimigos_fases[self.indice_lista_inimigos]):
                    self.gerar_inimigos(i,2)
                if self.indice_lista_inimigos == 9:
                    apresentar_clear = True
                    mostrar_pontuacao = True
                self.indice_lista_inimigos+=1
                
        return mostrar_level,level,apresentar_clear,nivel_fase

    def gerar_inimigos(self,cont,bosses):
        x_inimigo = 900
        if bosses==0:
            tipo_inimigo=random.randint(0,1)
            status_inimigo=[tipo_inimigo,x_inimigo,self.lista_y_inimigo[cont]*cont,True,self.lista_inimigos[tipo_inimigo][1],self.lista_inimigos[tipo_inimigo][2],12]
            self.inimigos_na_tela.append(status_inimigo)
        if bosses==1:
            tipo_inimigo=2
            status_inimigo=[tipo_inimigo,x_inimigo,self.lista_y_inimigo[cont]*cont,True,self.lista_inimigos[tipo_inimigo][1],self.lista_inimigos[tipo_inimigo][2],200]
            self.inimigos_na_tela.append(status_inimigo)
        if bosses==2:
            tipo_inimigo=3
            status_inimigo=[tipo_inimigo,x_inimigo,self.lista_y_inimigo[cont]*cont,True,self.lista_inimigos[tipo_inimigo][1],self.lista_inimigos[tipo_inimigo][2],600]
            self.inimigos_na_tela.append(status_inimigo)

    def blitar_explosao(self,tempo,screen):
        if len(self.lista_explosao)>0:
            i=0
            while i<len(self.lista_explosao):
                if self.lista_explosao[i][0] <=1:
                    screen.blit(self.explosao_inimigos,(self.lista_explosao[i][1],self.lista_explosao[i][2]))
                if self.lista_explosao[i][0] >=2:
                    screen.blit(self.explosao_chefao,(self.lista_explosao[i][1],self.lista_explosao[i][2]))
                if tempo - self.lista_explosao[i][3]>=0.3:
                    del self.lista_explosao[i]
                    i-=1
                i+=1

    def barra_de_vida_boss(self,screen):
        barra = 600 - self.inimigos_na_tela[0][6]
        pygame.draw.rect(screen, Cores.RED, (770, 0, 30, 600))
        pygame.draw.rect(screen, Cores.GREEN, (770, barra, 30, 600))
        return barra

    def explosao(self,x_exp,y_exp,tipo_exp,tempo_ini):
        self.lista_explosao
        lista=[]
        lista.append(tipo_exp)
        lista.append(x_exp)
        lista.append(y_exp)
        lista.append(tempo_ini)
        self.lista_explosao.append(lista)

    def blitar_tiro_chefao(self,screen):
        if self.indice_lista_inimigos == 9:
            cont = 0
            for r in range(0,len(self.bullets_inimigos),2):
                self.bullets_inimigos[r+1] += self.lista_pos_chefao[cont]
                self.bullets_inimigos[r] -= 5
                cont += 1
                if cont > 4:
                    cont = 0
            for r in range(0,len(self.bullets_inimigos),2):
                if len(self.bullets_inimigos) > 0:
                    if self.bullets_inimigos[0] < 0:
                        del self.bullets_inimigos[1]
                        del self.bullets_inimigos[0]
            for r in range(0 , len(self.bullets_inimigos) , 2):
                pygame.draw.circle(screen, Cores.RED, [self.bullets_inimigos[r], self.bullets_inimigos[r+1]], 10)
        else:
            cont = 0
            for r in range(0,len(self.bullets_inimigos),2):
                self.bullets_inimigos[r+1] += self.lista_pos_miniChefao[cont]
                self.bullets_inimigos[r] -= 5
                cont += 1
                if cont > 2:
                    cont = 0
            for r in range(0,len(self.bullets_inimigos),2):
                if len(self.bullets_inimigos) > 0:
                    if self.bullets_inimigos[0] < 0:
                        del self.bullets_inimigos[1]
                        del self.bullets_inimigos[0]
            for r in range(0 , len(self.bullets_inimigos) , 2):
                pygame.draw.circle(screen, Cores.RED, [self.bullets_inimigos[r], self.bullets_inimigos[r+1]], 10)

    def blitar_tiro_inimigo(self,screen):
        for r in range(0,len(self.red_bullets),2):
            self.red_bullets[r] -= 6
        for r in range(0,len(self.red_bullets),2):
            if len(self.red_bullets) > 0:
                if self.red_bullets[0] < 0:
                    del self.red_bullets[1]
                    del self.red_bullets[0]
        for r in range(0 , len(self.red_bullets) , 2):
            pygame.draw.rect(screen, Cores.RED, (self.red_bullets[r], self.red_bullets[r+1], 10, 5))

    def spawn_inimigos(self,count,screen):
        for i in range(len(self.inimigos_na_tela)):
            self.inimigos_na_tela[count][1],  self.inimigos_na_tela[count][2] = self.movimentacao_inimigo(i,screen)
            count+=1
        return 0

    def movimentacao_inimigo(self,count,screen):
        if 700<self.inimigos_na_tela[count][1]<=900 and self.inimigos_na_tela[count][0]<=1:
            self.inimigos_na_tela[count][1], self.inimigos_na_tela[count][2]= self.utils.colisao(self.inimigos_na_tela[count][1],
                                                                                            0,
                                                                                            self.inimigos_na_tela[count][2],
                                                                                            0,
                                                                                            self.lista_inimigos[self.inimigos_na_tela[count][0]][1],
                                                                                            800,
                                                                                            self.lista_inimigos[self.inimigos_na_tela[count][0]][2],
                                                                                            600,
                                                                                            False)
            self.inimigos_na_tela[count][1]-=1
        elif 450<self.inimigos_na_tela[count][1]<=900 and self.inimigos_na_tela[count][0]>=2:
            self.inimigos_na_tela[count][1], self.inimigos_na_tela[count][2]= self.utils.colisao(self.inimigos_na_tela[count][1],
                                                                                            0,
                                                                                            self.inimigos_na_tela[count][2],
                                                                                            0,
                                                                                            self.lista_inimigos[self.inimigos_na_tela[count][0]][1],
                                                                                            800,
                                                                                            self.lista_inimigos[self.inimigos_na_tela[count][0]][2],
                                                                                            600,
                                                                                            False)
            self.inimigos_na_tela[count][1]-=1
        else:
            self.inimigos_na_tela[count][1], self.inimigos_na_tela[count][2]= self.utils.colisao(self.inimigos_na_tela[count][1],
                                                                                            0,
                                                                                            self.inimigos_na_tela[count][2],
                                                                                            0,
                                                                                            self.lista_inimigos[self.inimigos_na_tela[count][0]][1],
                                                                                            800,
                                                                                            self.lista_inimigos[self.inimigos_na_tela[count][0]][2],
                                                                                            600,
                                                                                            True)
            if self.inimigos_na_tela[count][2] == 600-self.lista_inimigos[self.inimigos_na_tela[count][0]][2]:
                self.inimigos_na_tela[count][3]=False
            if self.inimigos_na_tela[count][2] == 0:
                self.inimigos_na_tela[count][3]=True
            if self.inimigos_na_tela[count][3]:
                self.inimigos_na_tela[count][2]+=2
            if self.inimigos_na_tela[count][3]==False:
                self.inimigos_na_tela[count][2]-=2
            opt = random.randint(0,100)
            if opt == 7:
                self.atirar_inimigos(self.inimigos_na_tela[count][1],self.inimigos_na_tela[count][2], self.inimigos_na_tela[count][4],self.inimigos_na_tela[count][5])
            if opt == 87 and self.inimigos_na_tela[count][0] == 3:
                self.atirar_chefao(self.inimigos_na_tela[count][1],self.inimigos_na_tela[count][2], self.inimigos_na_tela[count][4],self.inimigos_na_tela[count][5], 5)
            if opt == 45 and self.inimigos_na_tela[count][0] == 2:
                self.atirar_chefao(self.inimigos_na_tela[count][1],self.inimigos_na_tela[count][2], self.inimigos_na_tela[count][4],self.inimigos_na_tela[count][5], 3)
        screen.blit(self.lista_inimigos[self.inimigos_na_tela[count][0]][0],[self.inimigos_na_tela[count][1], self.inimigos_na_tela[count][2]])
        return self.inimigos_na_tela[count][1],  self.inimigos_na_tela[count][2]

    def atirar_inimigos(self,x_inimigo, y_inimigo, w_inimigo, h_inimigo):
        self.red_bullets.append(x_inimigo)
        self.red_bullets.append(y_inimigo + h_inimigo/2)

    def atirar_chefao(self,x_boss, y_boss, w_boss, h_boss, num_tiro):
        for i in range(num_tiro):
            self.bullets_inimigos.append(x_boss)
            self.bullets_inimigos.append(y_boss + h_boss // 2)






























        
